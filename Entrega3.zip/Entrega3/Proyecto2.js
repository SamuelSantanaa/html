{
    document.getElementById("demo").innerHTML = new Date();
};